Please have a check if a similar issue is already raised.

### Short Description

What is it about? Beauter or its Documentation? Is it a bug, feature or question?

### Platform

Version of Beauter? We assume the latest.
Browser. Also if its desktop or smartphone?

### Image

Add any image or animated GIFs that might be helpful for understanding.

### Brief Description of the problem

### Steps to Reproduce

### Expected behavior

### What happened instead

### Solution if any?
